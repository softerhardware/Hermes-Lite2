***N2ADR 

This directory contains files for fabrication of the N2ADR filter board for the Hermes-Lite 2. Please see
www.hermeslite.com for more details. Please contact steve@softerhardware.com with any questions.


***PCB Files:

Top layer:					pcb/n2adr.GTL
inner layer 2:				pcb/n2adr.GL2
inner layer 3:				pcb/n2adr.GL3
Bottom layer:				pcb/n2adr.GBL
Solder Stop Mask top:		pcb/n2adr.GTS
Solder Stop Mask Bottom:	pcb/n2adr.GBS
Silk Top:					pcb/n2adr.GTO
Silk Bottom:				pcb/n2adr.GBO
NC Drill:					pcb/n2adr.TXT
Mechanical layer :			pcb/n2adr.GML


***BOM Files:

Substitutions are allowed if the new part meets all specifications in the description field. 
For parts marked N (No) in Sub Okay field, no substitution is allowed unless agreed
to in writing by steve@softerhareware.com. Both BOMs contain part links for each BOM line for more details.

XLSX Format:				bom/n2adrbom.xlsx
PDF Format:					bom/n2adrbom.pdf


***Postion Files:

These files are for guidance only. Exact position of complex components with more than 2 pins must be checked and verified.

Top:						position/n2adr-top.pos
Bottom:						position/n2adr-bottom.pos
