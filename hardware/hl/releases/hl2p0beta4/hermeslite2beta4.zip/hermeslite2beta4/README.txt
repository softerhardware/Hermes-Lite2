***Hermes-Lite 2

This directory contains files for fabrication of the Hermes-Lite2 software defined transceiver. Please see
www.hermeslite.com for more details. Please contact steve@softerhardware.com with any questions.


***PCB Files:

Top layer:					pcb/hermeslite2.GTL
inner layer 2:				pcb/hermeslite2.GL2
inner layer 3:				pcb/hermeslite2.GL3
Bottom layer:				pcb/hermeslite2.GBL
Solder Stop Mask top:		pcb/hermeslite2.GTS
Solder Stop Mask Bottom:	pcb/hermeslite2.GBS
Silk Top:					pcb/hermeslite2.GTO
Silk Bottom:				pcb/hermeslite2.GBO
NC Drill:					pcb/hermeslite2.TXT
Mechanical layer :			pcb/hermeslite2.GML


***BOM Files:

Part ID is assigned for common parts. Substitutions are allowed if the new part meets all specifications in 
the description field. For parts marked N (No) in Sub Okay field, no substitution is allowed unless agreed
to in writing by steve@softerhareware.com. Both BOMs contain part links for each BOM line for more details.

PDF Format:					bom/hermeslite2bom.pdf
XLSX Format:				bom/hermeslite2bom.xlsx


***Postion Files:

These files are self explanatory text. They are for guidance only and positions may not be exact.

Top:						position/hermeslite2top.pos
Bottom:						position/hermeslite2bot.pos
